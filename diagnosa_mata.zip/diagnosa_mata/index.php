<?php 
include 'db.php';

// Generate CSRF token
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Diagnosa Penyakit Mata</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin-top: 20px;
        }
        .card-header {
            background-color: #007bff;
            color: white;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .navbar-brand {
            font-size: 1.5em;
            font-weight: bold;
        }
        .gejala-card {
            margin-bottom: 15px;
        }
        .gejala-description {
            font-size: 0.9em;
            color: #6c757d;
        }
        .gejala-image {
            max-height: 50px;
            max-width: 50px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Diagnosa Mata</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Diagnosa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Tentang</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Kontak</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <h1 class="text-center">Diagnosa Penyakit Mata</h1>
        <form action="diagnosis.php" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="form-group">
                <label for="gejala">Silakan Pilih Gejala Mata yang Anda Alami</label>
                <div class="row">
                    <?php
                    $sql = "SELECT * FROM gejala";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo '<div class="col-md-4 gejala-card">';
                            echo '<div class="card">';
                            echo '<div class="card-body">';
                            echo '<div class="form-check">';
                            echo '<input class="form-check-input" type="checkbox" name="gejala[' . $row["id_gejala"] . ']" value="1"';
                            if (isset($_POST['gejala'][$row["id_gejala"]])) echo ' checked';
                            echo '>';
                            echo '<label class="form-check-label">' . $row["nama_gejala"] . '</label>';
                            echo '</div>';
                            echo '<p class="gejala-description">' . $row["definisi"] . '</p>';
                            if (!empty($row["image"])) {
                                echo '<img src="images/' . $row["image"] . '" class="gejala-image" alt="' . $row["nama_gejala"] . '">';
                            }
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }
                    ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Diagnosa</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
