<?php 
include 'db.php';
// Mulai sesi untuk memastikan keamanan
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dashboard Diagnosa Penyakit Mata</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e0f7fa;
        }
        .card {
            margin-top: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .navbar {
            margin-bottom: 20px;
        }
        .navbar-brand {
            font-size: 1.5em;
            font-weight: bold;
        }
        .card-header {
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            transition: background-color 0.3s, border-color 0.3s;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Diagnosa Mata</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Diagnosa</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="tentang.php">tentang</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="kontak.php">kontak</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <!-- Panel Informasi -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-eye"></i> Informasi Kesehatan Mata
                    </div>
                    <div class="card-body">
                        <p>Selamat datang di sistem diagnosa penyakit mata. Gunakan navigasi di atas untuk mulai melakukan diagnosa atau mendapatkan informasi lebih lanjut.</p>
                    </div>
                </div>
            </div>
            <!-- Panel Statistik Pengguna -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <i class="fas fa-chart-bar"></i> Statistik Pengguna
                    </div>
                    <div class="card-body">
                        <p>Total Diagnosa: <strong>120</strong></p>
                        <p>Penyakit Terbanyak: <strong>Miopia</strong></p>
                    </div>
                </div>
            </div>
            <!-- Panel Navigasi -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-warning text-white">
                        <i class="fas fa-cogs"></i> Navigasi Cepat
                    </div>
                    <div class="card-body">
                        <a href="index.php" class="btn btn-primary btn-block">Mulai Diagnosa</a>
                        <a href="riwayat_diagnosa.php" class="btn btn-primary btn-block">Lihat Riwayat Diagnosa</a>
                        <a href="informasi.php" class="btn btn-primary btn-block">Informasi Penyakit Mata</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Panel Grafik -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <i class="fas fa-chart-line"></i> Grafik Kesehatan Mata
                    </div>
                    <div class="card-body">
                        <canvas id="myChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni'],
                datasets: [{
                    label: 'Jumlah Diagnosa',
                    data: [10, 20, 15, 30, 25, 40],
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
