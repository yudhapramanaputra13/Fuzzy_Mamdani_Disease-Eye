<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Informasi Penyakit Mata</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin-top: 20px;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .navbar-brand {
            font-size: 1.5em;
            font-weight: bold;
        }
        .content-section {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="dashboard.php">Diagnosa Mata</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Diagnosa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tentang.php">Tentang</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kontak.php">Kontak</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="content-section">
            <h2>Informasi Penyakit Mata</h2>
            <div class="card">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-eye"></i> Penyakit Mata Umum
                </div>
                <div class="card-body">
                    <h5>Miopia (Rabun Jauh)</h5>
                    <p>Miopia adalah kondisi di mana seseorang dapat melihat objek dekat dengan jelas, tetapi objek yang jauh terlihat kabur. Ini terjadi karena bentuk mata yang membuat cahaya jatuh di depan retina, bukan langsung di atasnya.</p>
                    
                    <h5>Hipermetropia (Rabun Dekat)</h5>
                    <p>Hipermetropia adalah kondisi di mana seseorang dapat melihat objek yang jauh dengan jelas, tetapi objek yang dekat terlihat kabur. Ini terjadi karena cahaya jatuh di belakang retina.</p>
                    
                    <h5>Glaukoma</h5>
                    <p>Glaukoma adalah penyakit mata yang merusak saraf optik mata, yang biasanya terjadi akibat tekanan yang sangat tinggi di dalam mata. Jika tidak segera diobati, glaukoma dapat menyebabkan kebutaan permanen.</p>
                    
                    <h5>Katarak</h5>
                    <p>Katarak adalah kekeruhan pada lensa mata yang dapat menyebabkan penglihatan kabur. Ini umumnya terjadi pada orang yang lebih tua dan dapat diobati dengan operasi.</p>

                    <h5>Astigmatisme</h5>
                    <p>Astigmatisme adalah kondisi di mana kornea atau lensa di dalam mata memiliki kelengkungan yang tidak rata, sehingga menyebabkan penglihatan kabur atau terdistorsi. Ini bisa diobati dengan kacamata, lensa kontak, atau operasi.</p>

                    <h5>Presbiopia</h5>
                    <p>Presbiopia adalah kondisi yang terjadi seiring bertambahnya usia, di mana mata kehilangan kemampuan untuk fokus pada objek yang dekat. Ini biasanya mulai muncul pada usia 40-an dan dapat diatasi dengan kacamata atau lensa kontak khusus.</p>

                    <h5>Retinopati Diabetik</h5>
                    <p>Retinopati diabetik adalah komplikasi dari diabetes yang mempengaruhi mata. Ini terjadi ketika kadar gula darah yang tinggi merusak pembuluh darah di retina, yang dapat menyebabkan kebutaan jika tidak ditangani dengan benar.</p>

                    <h5>Degenerasi Makula</h5>
                    <p>Degenerasi makula adalah penyakit yang menyebabkan kerusakan pada makula, bagian kecil dari retina yang bertanggung jawab untuk penglihatan sentral. Ini adalah penyebab utama kehilangan penglihatan pada orang dewasa yang lebih tua.</p>

                    <h5>Konjungtivitis</h5>
                    <p>Konjungtivitis, atau mata merah, adalah peradangan atau infeksi pada konjungtiva, selaput tipis yang melapisi bagian dalam kelopak mata dan menutupi bagian putih mata. Ini bisa disebabkan oleh infeksi bakteri atau virus, alergi, atau iritasi.</p>

                    <h5>Uveitis</h5>
                    <p>Uveitis adalah peradangan pada uvea, lapisan tengah mata. Penyebabnya bisa bermacam-macam, termasuk infeksi, penyakit autoimun, atau penyebab lainnya yang tidak diketahui. Gejalanya meliputi mata merah, nyeri, dan penglihatan kabur.</p>

                    <h5>Retinitis Pigmentosa</h5>
                    <p>Retinitis Pigmentosa adalah penyakit genetik yang menyebabkan degenerasi retina secara bertahap, yang akhirnya dapat menyebabkan kebutaan. Gejala awal sering kali termasuk kesulitan melihat di malam hari dan kehilangan penglihatan tepi.</p>

                    <h5>Keratitis</h5>
                    <p>Keratitis adalah peradangan pada kornea yang bisa disebabkan oleh infeksi, cedera, atau penggunaan lensa kontak yang tidak tepat. Gejalanya termasuk mata merah, nyeri, penglihatan kabur, dan sensitivitas terhadap cahaya.</p>

                    <h5>Blefaritis</h5>
                    <p>Blefaritis adalah peradangan pada kelopak mata yang biasanya disebabkan oleh infeksi bakteri atau kondisi kulit seperti rosacea. Gejalanya termasuk gatal, kemerahan, dan kelopak mata yang bengkak.</p>

                    <h5>Abiasi Retina</h5>
                    <p>Abiasi retina terjadi ketika retina terlepas dari lapisan pendukungnya di belakang mata. Ini adalah kondisi medis darurat yang memerlukan perawatan segera untuk mencegah kehilangan penglihatan permanen.</p>

                    <h5>Strabismus (Mata Juling)</h5>
                    <p>Strabismus adalah kondisi di mana kedua mata tidak sejajar dengan benar dan melihat ke arah yang berbeda. Ini bisa disebabkan oleh ketidakseimbangan otot mata dan dapat diobati dengan kacamata, latihan mata, atau operasi.</p>

                    <h5>Ambliopia (Mata Malas)</h5>
                    <p>Ambliopia adalah kondisi di mana satu mata gagal berkembang dengan baik, menyebabkan penglihatan yang buruk pada mata tersebut. Ini biasanya terjadi pada anak-anak dan dapat diobati dengan menutup mata yang lebih kuat untuk memaksa mata yang lemah bekerja lebih keras.</p>

                    <h5>Trakoma</h5>
                    <p>Trakoma adalah infeksi mata yang disebabkan oleh bakteri Chlamydia trachomatis. Ini adalah penyebab utama kebutaan menular di seluruh dunia. Gejalanya termasuk iritasi mata ringan sampai parah, dan jika tidak diobati, dapat menyebabkan kebutaan.</p>

                    <h5>Herpes Zoster Oftalmikus</h5>
                    <p>Herpes zoster oftalmikus adalah infeksi virus yang mempengaruhi mata dan area sekitarnya, sering kali menyebabkan ruam yang menyakitkan. Ini adalah bentuk dari herpes zoster yang disebabkan oleh virus varicella-zoster.</p>

                    <h5>Koloboma</h5>
                    <p>Koloboma adalah kondisi bawaan yang ditandai dengan celah atau lubang di salah satu struktur mata, seperti iris, retina, atau saraf optik. Ini dapat mempengaruhi penglihatan tergantung pada lokasi dan ukuran celah tersebut.</p>

                    <h5>Chalazion</h5>
                    <p>Chalazion adalah benjolan di kelopak mata yang disebabkan oleh penyumbatan kelenjar minyak. Ini berbeda dengan stye karena tidak menyakitkan dan biasanya hilang dengan sendirinya atau dengan perawatan sederhana.</p>

                    <h5>Neuritis Optik</h5>
                    <p>Neuritis optik adalah peradangan pada saraf optik yang dapat menyebabkan kehilangan penglihatan sementara atau permanen. Ini sering dikaitkan dengan multiple sclerosis, tetapi juga bisa disebabkan oleh infeksi atau penyakit autoimun lainnya.</p>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
