<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gejala_input = $_POST['gejala'];

    // Debug: Output gejala input untuk memastikan data masuk dengan benar
    echo "<pre>";
    print_r($gejala_input);
    echo "</pre>";

    // Implementasi Fuzzy tsukamoto
    $sql = "SELECT * FROM aturan";
    $result = $conn->query($sql);

    $fuzzy_values = [];

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $id_penyakit = $row["id_penyakit"];
            $id_gejala = $row["id_gejala"];
            $nilai_keanggotaan = $row["nilai_keanggotaan"];
            $nilai_gejala = isset($gejala_input[$id_gejala]) ? $gejala_input[$id_gejala] : 0;

            // Menghitung nilai fuzzy dengan metode tsukomoto
            $fuzzy_value = min($nilai_keanggotaan, $nilai_gejala);
            if (!isset($fuzzy_values[$id_penyakit])) {
                $fuzzy_values[$id_penyakit] = [];
            }
            $fuzzy_values[$id_penyakit][] = $fuzzy_value;

            // Debugging: Output each calculation step
            echo "Penyakit ID: $id_penyakit, Gejala ID: $id_gejala, Nilai Keanggotaan: $nilai_keanggotaan, Nilai Gejala: $nilai_gejala, Fuzzy Value: $fuzzy_value<br>";
        }
    }

    // Defuzzifikasi
    $hasil_diagnosis = [];
    foreach ($fuzzy_values as $id_penyakit => $values) {
        $hasil_diagnosis[$id_penyakit] = max($values);

        // Debugging: Output each defuzzification step
        echo "Hasil Diagnosis - Penyakit ID: $id_penyakit, Nilai: " . max($values) . "<br>";
    }

    // Menentukan penyakit dengan nilai keanggotaan tertinggi
    $id_penyakit_tertinggi = array_keys($hasil_diagnosis, max($hasil_diagnosis))[0];

    $sql = "SELECT nama_penyakit FROM penyakit WHERE id_penyakit = $id_penyakit_tertinggi";
    $result = $conn->query($sql);
    $nama_penyakit = $result->fetch_assoc()["nama_penyakit"];

    // Store debug information in a variable
    $debug_info = ob_get_clean();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Hasil Diagnosis</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Hasil Diagnosis</h1>
        <div class="alert alert-info">
            <p>Penyakit yang terdeteksi: <strong><?php echo isset($nama_penyakit) ? $nama_penyakit : 'Tidak ditemukan'; ?></strong></p>
            <p>Nilai Kepercayaan: <strong><?php echo isset($hasil_diagnosis[$id_penyakit_tertinggi]) ? $hasil_diagnosis[$id_penyakit_tertinggi] : 'Tidak ditemukan'; ?></strong></p>
        </div>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
        <div class="mt-3">
            <!-- Hidden debug info for developers -->
            <details>
                <summary>Debug Information</summary>
                <div class="alert alert-secondary">
                    <?php echo $debug_info; ?>
                </div>
            </details>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
