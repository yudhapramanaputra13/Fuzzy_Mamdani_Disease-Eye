<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Tentang Kami</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin-top: 20px;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .navbar-brand {
            font-size: 1.5em;
            font-weight: bold;
        }
        .content-section {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="dashboard.php">Diagnosa Mata</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Diagnosa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="informasi.php">Informasi Penyakit Mata</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kontak.php">Kontak</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="content-section">
            <h2>Tentang Kami</h2>
            <div class="card">
                <div class="card-header bg-secondary text-white">
                    <i class="fas fa-info-circle"></i> Tentang Diagnosa Mata
                </div>
                <div class="card-body">
                    <p>Diagnosa Mata adalah platform yang dirancang untuk melakukan diagnosa awal terhadap berbagai penyakit mata secara online. Platform ini memberikan kemudahan bagi pengguna untuk mengetahui kondisi kesehatan mata mereka tanpa harus langsung pergi ke klinik atau rumah sakit. Kami menggunakan teknologi terbaru dalam bidang kecerdasan buatan untuk memberikan hasil diagnosa yang cepat dan akurat.

Visi kami adalah untuk meningkatkan kesadaran masyarakat terhadap kesehatan mata dan memudahkan akses informasi terkait penyakit mata. Kami percaya bahwa dengan memberikan informasi yang tepat dan layanan diagnosa yang mudah diakses, masyarakat dapat mengambil langkah pencegahan yang lebih baik untuk menjaga kesehatan mata mereka.

Platform ini dilengkapi dengan berbagai fitur yang mendukung pengalaman pengguna yang optimal:

Diagnosa Online: Pengguna dapat memilih gejala yang mereka alami dan mendapatkan hasil diagnosa awal mengenai kemungkinan penyakit mata yang mereka derita. Proses ini dilakukan dengan menggunakan algoritma canggih yang telah diuji keakuratannya.

Informasi Penyakit Mata: Kami menyediakan database yang lengkap mengenai berbagai penyakit mata, termasuk gejala, penyebab, dan metode pengobatan. Informasi ini diharapkan dapat membantu pengguna untuk memahami kondisi mereka dengan lebih baik.

Statistik Pengguna: Pengguna dapat melihat statistik terkait penggunaan platform, termasuk jumlah diagnosa yang telah dilakukan dan penyakit mata yang paling sering terdeteksi.

Navigasi Cepat: Platform ini dirancang dengan antarmuka yang ramah pengguna dan navigasi yang mudah. Pengguna dapat dengan cepat mengakses berbagai fitur yang tersedia, seperti melakukan diagnosa, melihat riwayat diagnosa, dan mendapatkan informasi penyakit mata.

Keamanan Data: Kami menjamin keamanan data pengguna dengan menerapkan protokol keamanan yang ketat. Data pengguna dienkripsi dan hanya digunakan untuk keperluan diagnosa dan peningkatan layanan.

Layanan Pelanggan: Tim layanan pelanggan kami siap membantu pengguna dalam menyelesaikan masalah teknis dan menjawab pertanyaan terkait penggunaan platform.

Diagnosa Mata dikembangkan oleh tim profesional yang terdiri dari dokter spesialis mata, ahli kecerdasan buatan, dan pengembang perangkat lunak. Kami terus melakukan penelitian dan pengembangan untuk meningkatkan akurasi dan efisiensi platform ini.

Terima kasih telah menggunakan Diagnosa Mata. Kami berharap platform ini dapat membantu Anda dalam menjaga kesehatan mata Anda dan keluarga. Jika Anda memiliki pertanyaan atau masukan, jangan ragu untuk menghubungi kami melalui halaman Kontak.

</div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
