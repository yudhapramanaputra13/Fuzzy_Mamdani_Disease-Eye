-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for diagnosa_penyakit_mata
CREATE DATABASE IF NOT EXISTS `diagnosa_penyakit_mata` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `diagnosa_penyakit_mata`;

-- Dumping structure for table diagnosa_penyakit_mata.aturan
CREATE TABLE IF NOT EXISTS `aturan` (
  `id_aturan` int NOT NULL AUTO_INCREMENT,
  `id_penyakit` int DEFAULT NULL,
  `id_gejala` int DEFAULT NULL,
  `nilai_keanggotaan` float DEFAULT NULL,
  PRIMARY KEY (`id_aturan`),
  KEY `id_penyakit` (`id_penyakit`),
  KEY `id_gejala` (`id_gejala`),
  CONSTRAINT `aturan_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`),
  CONSTRAINT `aturan_ibfk_2` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table diagnosa_penyakit_mata.aturan: ~33 rows (approximately)
INSERT INTO `aturan` (`id_aturan`, `id_penyakit`, `id_gejala`, `nilai_keanggotaan`) VALUES
	(1, 1, 1, 0.8),
	(2, 1, 2, 0.7),
	(3, 2, 1, 0.9),
	(4, 3, 3, 1),
	(6, 1, 36, 0.5),
	(7, 2, 37, 0.4),
	(8, 2, 38, 0.3),
	(9, 3, 39, 0.9),
	(10, 3, 40, 0.8),
	(11, 1, 41, 0.7),
	(12, 2, 42, 0.6),
	(13, 3, 43, 0.5),
	(14, 1, 44, 0.4),
	(15, 2, 45, 0.3),
	(16, 3, 46, 0.2),
	(17, 1, 47, 0.8),
	(18, 2, 48, 0.7),
	(19, 3, 49, 0.6),
	(20, 1, 50, 0.5),
	(21, 2, 51, 0.4),
	(22, 3, 52, 0.3),
	(23, 1, 53, 0.2),
	(24, 2, 54, 0.1),
	(25, 3, 55, 0.9),
	(26, 1, 56, 0.8),
	(27, 2, 57, 0.7),
	(28, 3, 58, 0.6),
	(29, 1, 59, 0.5),
	(30, 2, 60, 0.4),
	(31, 3, 61, 0.3),
	(32, 1, 62, 0.2),
	(33, 2, 63, 0.1),
	(34, 3, 64, 0.9);

-- Dumping structure for table diagnosa_penyakit_mata.diagnosis
CREATE TABLE IF NOT EXISTS `diagnosis` (
  `id_diagnosis` int NOT NULL AUTO_INCREMENT,
  `tanggal` date DEFAULT NULL,
  `hasil_diagnosis` varchar(100) DEFAULT NULL,
  `nilai_kepercayaan` float DEFAULT NULL,
  PRIMARY KEY (`id_diagnosis`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table diagnosa_penyakit_mata.diagnosis: ~15 rows (approximately)
INSERT INTO `diagnosis` (`id_diagnosis`, `tanggal`, `hasil_diagnosis`, `nilai_kepercayaan`) VALUES
	(1, '2024-06-18', 'Konjungtivitis', 0.85),
	(2, '2024-06-19', 'Uveitis Anterior', 0.75),
	(3, '2024-06-20', 'Katarak', 0.8),
	(4, '2024-06-21', 'Glaukoma', 0.85),
	(5, '2024-06-22', 'Ulkus kornea', 0.7),
	(6, '2024-06-23', 'Dakriosistitis', 0.65),
	(7, '2024-06-24', 'Blefaritis', 0.9),
	(8, '2024-06-25', 'Presbiopia', 0.6),
	(9, '2024-06-26', 'Myopia', 0.95),
	(10, '2024-06-27', 'Retinopati', 0.8),
	(11, '2024-06-28', 'Retinitis Pigmentosa', 0.75),
	(12, '2024-06-29', 'Keratitis', 0.85),
	(13, '2024-06-30', 'Astigmatisma', 0.7),
	(14, '2024-07-01', 'Degenerasi Makula', 0.65),
	(15, '2024-07-02', 'Sindrom Mata Kering', 0.9);

-- Dumping structure for table diagnosa_penyakit_mata.gejala
CREATE TABLE IF NOT EXISTS `gejala` (
  `id_gejala` int NOT NULL AUTO_INCREMENT,
  `nama_gejala` varchar(255) DEFAULT NULL,
  `definisi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`id_gejala`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table diagnosa_penyakit_mata.gejala: ~42 rows (approximately)
INSERT INTO `gejala` (`id_gejala`, `nama_gejala`, `definisi`) VALUES
	(1, 'Mata Merah', 'Kondisi mata yang berwarna merah karena iritasi.'),
	(2, 'Gatal', 'Rasa gatal di sekitar mata.'),
	(3, 'Penglihatan Kabur', 'Penglihatan yang tidak jelas atau buram.'),
	(36, 'penglihatan mulai samar-samar dan berkabut', ''),
	(37, 'Mudah Silau', ''),
	(38, 'hanya bisa melihat normal pada cukup cahaya', ''),
	(39, 'Terlihat DUA', ''),
	(40, 'Mengapa katarak terlihat sembirat kuning/ coklat', ''),
	(41, 'Sering Ganti lensa', ''),
	(42, 'Warna memudar', ''),
	(43, 'Penglihatan kacau waktu malam', ''),
	(44, 'Merasa melihat lingkaran', ''),
	(45, 'Terganggu dengan cahaya gelap', ''),
	(46, 'Mata tampak berair dan berkabut', ''),
	(47, 'Mata menjadi sensitif terhadap cahaya', ''),
	(48, 'Mata terlihat membesar (akibat tekanan yang terjadi di dalam mata)', ''),
	(49, 'Mata terlihat juling', ''),
	(50, 'Kelenjar getah bening yang membesar di depan telinga', ''),
	(51, 'Mata terasa seperti terbakar', ''),
	(52, 'Saat bangun pagi, bulu mata akan terasa menempel atau lengket', ''),
	(53, 'Mata terasa seperti berpasir', ''),
	(54, 'Peradangan yang disebabkan bakteri akan memberikan gambaran klinik rasa sakit yang sangat', ''),
	(55, 'kelopak merah dan bengkak, kelopak sukar dibuka', ''),
	(56, 'konjungtiva kemotik dan merah, kornea keruh, bilik mata depan keruh', ''),
	(57, 'terjadi penurunan tajam penglihatan dan fotofobia (takut cahaya)', ''),
	(58, 'Endoftalmitis akibat pembedahan biasa terjadi setelah 24 jam dan penglihatan akan semakin memburuk dengan berlalunya waktu. Bila sudah memburuk, akan terbentuk hipopion, yaitu kantung berisi cairan', ''),
	(59, 'Kecenderungan untuk memegang bacaan lebih jauh, agar bisa lebih jelas melihat huruf.', ''),
	(60, 'Menyipitkan mata.', ''),
	(61, 'Penglihatan kabur ketika membaca dengan jarak normal.', ''),
	(62, 'Butuh lampu lebih terang saat membaca.', ''),
	(63, 'Sakit kepala atau mata menegang setelah membaca.', ''),
	(64, 'Kesulitan membaca cetakan huruf yang berukuran kecil.', ''),
	(65, 'Bintik mengambang (floater) pada lapangan pandang.', ''),
	(66, 'Titik gelap pada bagian tengah lapangan pandang.', ''),
	(67, 'Kesulitan melihat di malam hari.', ''),
	(68, 'Sensitivitas Cahaya', 'Mata menjadi sangat sensitif terhadap cahaya.'),
	(69, 'Mata Berair', 'Mata terus menerus berair tanpa sebab yang jelas.'),
	(70, 'Nyeri Mata', 'Merasa nyeri atau sakit pada mata.'),
	(71, 'Penglihatan Menurun', 'Penglihatan semakin menurun seiring waktu.'),
	(72, 'Bintik Hitam', 'Melihat bintik hitam dalam penglihatan.'),
	(73, 'Cahaya Kilat', 'Melihat kilatan cahaya dalam penglihatan.'),
	(74, 'Mata Merah', 'Mata berwarna merah karena peradangan atau infeksi.');

-- Dumping structure for table diagnosa_penyakit_mata.gejala_diagnosis
CREATE TABLE IF NOT EXISTS `gejala_diagnosis` (
  `id_diagnosis` int DEFAULT NULL,
  `id_gejala` int DEFAULT NULL,
  `nilai_gejala` float DEFAULT NULL,
  KEY `id_diagnosis` (`id_diagnosis`),
  KEY `id_gejala` (`id_gejala`),
  CONSTRAINT `gejala_diagnosis_ibfk_1` FOREIGN KEY (`id_diagnosis`) REFERENCES `diagnosis` (`id_diagnosis`),
  CONSTRAINT `gejala_diagnosis_ibfk_2` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table diagnosa_penyakit_mata.gejala_diagnosis: ~24 rows (approximately)
INSERT INTO `gejala_diagnosis` (`id_diagnosis`, `id_gejala`, `nilai_gejala`) VALUES
	(1, 1, 0.8),
	(1, 2, 0.7),
	(1, 3, 0.9),
	(1, 36, 0.6),
	(1, 37, 0.5),
	(1, 38, 0.7),
	(1, 39, 0.8),
	(1, 40, 0.6),
	(1, 41, 0.9),
	(1, 42, 0.5),
	(1, 36, 0.6),
	(1, 37, 0.5),
	(1, 38, 0.7),
	(1, 39, 0.8),
	(1, 40, 0.6),
	(1, 41, 0.9),
	(1, 42, 0.5),
	(1, 68, 0.8),
	(1, 69, 0.7),
	(2, 70, 0.6),
	(2, 71, 0.9),
	(3, 72, 0.5),
	(3, 73, 0.7),
	(3, 74, 0.8);

-- Dumping structure for table diagnosa_penyakit_mata.penyakit
CREATE TABLE IF NOT EXISTS `penyakit` (
  `id_penyakit` int NOT NULL AUTO_INCREMENT,
  `nama_penyakit` varchar(100) NOT NULL,
  `definisi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `solusi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  PRIMARY KEY (`id_penyakit`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table diagnosa_penyakit_mata.penyakit: ~15 rows (approximately)
INSERT INTO `penyakit` (`id_penyakit`, `nama_penyakit`, `definisi`, `solusi`) VALUES
	(1, 'Konjungtivitis', 'Iritasi atau peradangan pada konjungtiva.', NULL),
	(2, 'Uveitis Anterior', 'Peradangan pada iris.', NULL),
	(3, 'Katarak', 'Kondisi lensa mata yang menjadi keruh.', NULL),
	(4, 'Glaukoma', 'Glaukoma merunjuk pada sekelompok penyakit yang menyerang saraf optik dan melibatkan hilangnya sel ganglion retina dalam pola yang khas. Glaukoma adalah sejenis neuropati (penyakit saraf) optik. Tekanan intraocular yang miningkat merupakan faktor resiko yang signifikan pada perkembangan glaucoma (di atas 22 mmHg atau 2,9 kPa). Eseorang bias mengalami kerusakan saraf pada tekanan yang relatif rendah, sementara orang lain mungkin mempuanyai tekanan bola mata tinggi selama bertahun-tahun tapi tidak pernah menagalami kerusakan. Penyakit glaukoma yang tidak di obati akan mengakibatkan kerusan sarf optik yang permanen dan pada gilirannya akan kehilangan bidang penglihatan, yang dapat berkembang menjadi kebutaan.', 'Glaukoma bisa ditangani dengan obat tetes mata, obat-obatan yang diminum, pengobatan laser, atau prosedur operasi. Obat tetes mata Umumnya obat tetes mata sering menjadi bentuk penanganan pertama untuk glaukoma yang disarankan oleh dokter. Obat tetes ini berguna melancarkan pembuangan cairan mata (aqueous humour) atau mengurangi produksinya. Beberapa jenis obat tetes mata untuk glaukoma adalah: Alpha-adrenergic agonists. Obat ini berfungsi meningkatkan aliran aqueous humour dan mengurangi produksinya. Efek samping yang mungkin saja terjadi setelah menggunakan alpha-adrenergic agonists adalah pembengkakan, gatal, dan merah pada mata, badan terasa lelah, mulut kering, hipertensi, dan detak jantung tidak teratur. Beberapa contoh obat ini adalah brimonidine dan apraclonidine. Beta-blockers. Obat ini bekerja dengan cara memperlambat produksi aqueous humour guna mengurangi tekanan intraokular pada mata. Efek samping yang mungkin terjadi setelah mengonsumsi beta-blockers adalah mata terasa gatal, tersengat, atau panas. Mata juga bisa menjadi kering. Beberapa contoh obat ini adalah timolol, levobunolol hydrochloride, dan betaxolol hydrochloride. Prostaglandin analogue. Obat ini mampu memperlancar pengaliran aqueous humour sehingga tekanan di dalam mata berkurang. Efek samping yang mungkin terjadi setelah mengonsumsi prostaglandin analogue adalah sakit, bengkak, dan merah pada mata, mata menjadi sensitif terhadap cahaya, mata menjadi kering, menggelapnya warna mata, pembuluh darah pada bagian putih mata menjadi bengkak, serta sakit kepala. Beberapa contoh obat ini adalah travoprost, bimatoprost, latanoprost, dan tafluprost. Carbonic anhydrase inhibitors. Obat ini bekerja dengan cara mengurangi produksi aqueous humour sehingga tekanan di dalam mata berkurang. Efek samping yang mungkin terjadi setelah mengonsumsi carbonic anhydrase inhibitors adalah iritasi pada mata, mulut terasa pahit dan kering, serta mual. Beberapa contoh obat ini adalah dorzolamide dan brinzolamide. Cholinergic agents atau miotic. Obat ini bekerja dengan cara meningkatkan pengaliran aqueous humour. Efek samping yang mungkin terjadi setelah mengonsumsi cholinergic agents atau miotic adalah penglihatan menjadi buram dan pupil mengecil. Salah satu contoh obat ini adalah pilocarpine. Sympathomimetics. Obat ini mampu memperlancar pengaliran aqueous humour sekaligus mengurangi produksinya. Efek samping yang mungkin terjadi setelah mengonsumsi sympathomimetics adalah nyeri dan merah pada mata. Salah satu contoh obat ini adalah brimonidine tartrate. Obat tetes mata tidak boleh digunakan secara sembarangan tanpa resep atau petunjuk penggunaannya dari dokter karena dikhawatirkan bisa berbahaya. Contohnya adalah reaksi obat beta-blockers yang malah memperburuk kondisi orang yang memiliki penyakit jantung dan asma. Obat-obatan glaukoma yang diminum Untuk melengkapi kinerja obat tetes atau jika obat tetes terbukti kurang efektif, dokter kemungkinan akan meresepkan obat glaukoma yang diminum. Salah satu contohnya adalah carbonic anhydrase inhibitor. Efek samping yang mungkin terjadi setelah mengonsumsi obat ini adalah: Sakit perut Jari tangan atau kaki kesemutan Sering buang air kecil Batu ginjal Depresi Terapi laser Pada kasus glaukoma sudut tertutup, terapi laser ditujukan untuk membuka penyumbatan aqueous humour. Sedangkan pada kasus glaukoma sudut tertutup terapi laser ditujukan untuk memperlancar pengaliran cairan tersebut. Berdasarkan tekniknya, terapi laser dibagi menjadi tiga, yaitu: Trabeculoplasty. Sumbatan di area trabecular meshwork dibuka menggunakan sinar laser. Iridotomy. Aliran aqueous humour diperlancar dengan cara membuat lubang kecil pada iris menggunakan sinar laser. Cyclodiode Laser Treatment. Produksi aqueous humour dibatasi dengan cara merusak sebagian kecil jaringan penghasil aqueous humour. Prosedur operasi Berikut ini adalah jenis-jenis operasi glaukoma jika diurutkan berdasarkan penerapannya secara umum: Trabeculectomy. Ini merupakan jenis operasi glaukoma yang paling umum. Trabeculectomy bertujuan memperlancar aliran aqueous humour dengan cara membuang sebagian dari trabecular meshwork. Aqueous shunt implant. Ini merupakan prosedur operasi yang bertujuan memperlancar aliran aqueous humour dengan cara memasang sebuah alat kecil menyerupai selang pada mata. Viscocanalostomy. Melalui operasi ini dokter akan membuang sebagian lapisan luar berwarna putih yang menutupi bola mata (sclera) untuk meningkatkan pembuangan aqueous humour. Sclerectomy dalam. Operasi ini dilakukan guna memperlebar trabecular meshwork melalui pemasangan alat untuk melebarkan trabecular meshwork.'),
	(5, 'Ulkus kornea', 'Ulkus kornea yaitu luka terbuka pada lapisan kornea yang paling luar.', '-'),
	(6, 'Dakriosistitis', 'Dakriosistitis adalah suatu infeksi pada kantong air mata (sakus lakkrimalis).', '-'),
	(7, 'Blefaritis', 'Blefaritis adalah suatu peradangan pada kelopak mata. Blefaritis ditandai dengan pembebtukan minyak berlebihan didalm kelenjar di dekat kelopak mata yang merupakan lingkungan yang disukai oleh bakteri yang dalam keadaan normal ditemukan dikulit.', '-'),
	(8, 'Presbiopia', 'Presbiopia, yang biasa disebut penglihatan tua (presby = old = tua ; opia = vision = penglihatan) merupakan keadaan normal sehubunagn dengan usia, dimana kemampuan akomodasi seseoarang telah mengalami penurunan sehingga sampai pada tahap di mana penglihatan pada jarak dekat menjadi kurang jelas. Ini sejalan dengan penurunan fisiologis amlitudo akomodasi yang di mulai sejak seseorang berumur tahun, dan bervariasi dengan individu, pekerjaan, dan kelainan refraksi.', 'Pengobatan Presbiopi Tujuan pengobatan presbiopi adalah membantu ketidakmampuan mata untuk fokus pada benda berjarak dekat. Beberapa cara pengobatan presbiopi adalah: Kacamata. Penggunaan kacamata adalah cara sederhana dan aman untuk menangani presbiopia. Jika kacamata baca biasa tidak bisa menangani, pasien mungkin akan diresepkan kacamata berlensa khusus untuk presbiopia. Lensa kontak. Alat ini bisa digunakan bagi pasien yang tidak ingin mengenakan kacamata. Namun, lensa kontak mungkin tidak bisa digunakan jika penderita juga mengidap kondisi tidak normal pada kelopak mata, saluran air mata, dan permukaan mata. Bedah refraktif. Prosedur ini bertujuan untuk mengubah bentuk kornea mata untuk meningkatkan penglihatan jarak dekat. Namun, pasien tetap membutuhkan kacamata usai pembedahan untuk aktivitas yang membutuhkan penglihatan jarak dekat. Implan lensa. Pada prosedur ini, lensa mata penderita akan diganti dengan lensa mata sintetis. Umumnya, pasien yang memilih prosedur ini pernah menjalani pembedahan LASIK sebelumnya. Inlay kornea. Dokter akan memasukkan ring plastik kecil di sudut setiap kornea mata untuk mengubah lengkungannya. Risiko inlay kornea lebih kecil jika dibandingkan tindakan pembedahan mata lainnya.'),
	(9, 'Myopia', 'Bila saat ini anda merasakn kesuliatan melihat benda yang jauh tetapi tidak masalah jika melihat benda yang dekat maka kemungkinan anda menderita apa yang dinamakan minus atau myopia. Myopia memang penyakit yang sangat populer dan menyerang antara 22% sampai 30% dari populasi. Gangguan mata ini dengan mudah dapat di koreksi menggunakan kaca mata, lensa kontak atau operasi', '-'),
	(10, 'Retinopati', 'Retinopati hipertensi (Hypertensive retinopathy) aaadalah kerusakan pada retina sebagai akibat tekanan darah tinggi.', ' Pengobatan Hal pertama dan penting untuk pengobatan adalah mengontrol kadar gula darah sehingga tetap berada dalam rentang nilai normal. Dengan demikian, keparahan penyakit dapat dihindari. Selain kami anjurkan pasien untuk terus menjaga diet makanan, kami sarankan pasien untuk mengkonsumsi kapsul herbal untuk mengatasi penyakit diabetesnya. Kita semua tahu bahwa diabetes memang tidak bisa disembuhkan secara total, tapi penyakit ini bisa ditekan efek sampingnya atau dijaga supaya tidak semakin parah dan penderita bisa hidup dengan cukup sehat. Pada retinopati yang mengalami perdarahan dapat dilakukan focal laser treatment untuk menghentikannya. Selain itu, terapi laser lain seperti scatter laser treatment dapat membantu mengecilkan pembuluh darah yang baru terbentuk. Jika perdarahan banyak, dapat dilakukan operasi untuk membuang darah tersebut. Tindakan ini disebut vitrektomi. Pencegahan Untuk mencegah timbulnya atau memberatnya retinopati diabetik, beberapa langkah dapat ditempuh, antara lain : Menerapkan gaya hidup sehat yaitu dengan makan makanan yang dianjurkan bagi penderita diabetes, berolahraga teratur, tidak merokok, hindari stress, dll. Mengecek kadar gula darah secara rutin untuk mengontrol kadar gula. Memeriksakan mata secara teratur setiap tahun. Manfaatnya adalah mengetahui perkembangan retinopati diabetik. Dengan demikian dapat dilakukan antisipasi agar penyakit ini tidak semakin parah. Pada tahap dini, retinopati diabetik relatif lebih mudah dikendalikan. Sampai saat ini, sudah banyak klien kami yang menggunakan Obat Terapi Mata Alami untuk membantu penderita diabetes yang mengalami KATARAK ataupun GLAUKOMA. Sedangkan untuk masalah retinopati, Obat Terapi Mata Alami berfungsi sebagai terapi penunjang, bukan terapi utama dan satu-satunya yang Anda andalkan. Jika Anda mengalami retinopati yang sudah sangat parah, kami sarankan Anda menghubungi dokter mata untuk pertolongan lebih lanjut.'),
	(11, 'Retinitis Pigmentosa', 'Retinitis Pigmentosa adalah sekelompok penyakit mata yang ditandai oleh kerusakan retina.', 'Pengobatan tergantung pada jenis retinitis, namun terapi gen dan vitamin A sering digunakan.'),
	(12, 'Keratitis', 'Keratitis adalah peradangan pada kornea mata.', 'Pengobatan termasuk antibiotik untuk infeksi bakteri dan obat anti-jamur untuk infeksi jamur.'),
	(13, 'Astigmatisma', 'Astigmatisma adalah kelainan refraksi di mana kornea atau lensa mata tidak berbentuk sempurna.', 'Pengobatan meliputi penggunaan kacamata atau lensa kontak, dan dalam beberapa kasus, pembedahan refraktif.'),
	(14, 'Degenerasi Makula', 'Degenerasi Makula adalah kondisi yang mempengaruhi bagian tengah retina yang disebut makula.', 'Pengobatan termasuk obat-obatan anti-VEGF dan terapi laser.'),
	(15, 'Sindrom Mata Kering', 'Sindrom Mata Kering terjadi ketika mata tidak menghasilkan cukup air mata atau ketika air mata menguap terlalu cepat.', 'Pengobatan meliputi penggunaan tetes mata pelumas, dan dalam beberapa kasus, pembedahan untuk mengurangi penguapan air mata.');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
